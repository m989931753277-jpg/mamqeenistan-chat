# ممقینستان چت — Android Build Project

- Application ID: `ir.mamqeenistan.chat`
- App name: `ممقینستان چت`
- Web app source: `app/src/main/assets/index.html`
- Build: `:app:assembleRelease`
- GitHub Actions workflow: `.github/workflows/build-apk.yml`

This project wraps the V6 HTML app in an Android WebView. Internet access is enabled because the app connects to Supabase.
