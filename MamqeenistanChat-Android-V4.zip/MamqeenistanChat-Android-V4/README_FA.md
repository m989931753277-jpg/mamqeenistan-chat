# ممقینستان چت — Android V3

این پروژه نسخه اصلاح‌شده وب‌اپ ممقینستان چت را داخل WebView اجرا می‌کند.

## اصلاح مهم V3
تداخل نام متغیر `supabase` با global کتابخانه Supabase JS برطرف شده است؛ خطای `Cannot read properties of undefined (reading 'auth')` نباید از این علت رخ دهد.

## Build
پروژه را در Android Studio باز کنید و Gradle Sync و سپس Build APK را اجرا کنید.

کلید استفاده‌شده در فرانت‌اند publishable است؛ service_role/secret داخل پروژه قرار نگرفته است.
